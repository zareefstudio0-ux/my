import { useState, useEffect, useRef } from 'react';
import { Play, Square, Loader2, Sparkles, User, BookMarked, Settings, Volume2, Wand2, Heart, Clock, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Types
interface Story {
  _id: string;
  title: string;
  author: string;
  story: string;
  moral: string;
}

function App() {
  const [story, setStory] = useState<Story | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isReading, setIsReading] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string>('');
  const [rate, setRate] = useState(1);
  const [pitch] = useState(1);
  const [showPromptModal, setShowPromptModal] = useState(false);
  const [userPrompt, setUserPrompt] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('');
  const [storyHistory, setStoryHistory] = useState<Story[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [favorites, setFavorites] = useState<Story[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);
  const [currentWordIndex, setCurrentWordIndex] = useState(-1);
  const storyContentRef = useRef<HTMLDivElement>(null);
  const currentWordRef = useRef<HTMLSpanElement>(null);
  
  const synth = window.speechSynthesis;

  const genres = [
    'Adventure', 'Fantasy', 'Mystery', 'Horror', 'Romance', 
    'Science Fiction', 'Comedy', 'Drama', 'Fable', 'Fairy Tale'
  ];

  // Auto-scroll effect when word changes
  useEffect(() => {
    if (isReading && currentWordRef.current && storyContentRef.current) {
      const wordElement = currentWordRef.current;
      const containerElement = storyContentRef.current;
      
      // Get positions
      const wordRect = wordElement.getBoundingClientRect();
      const containerRect = containerElement.getBoundingClientRect();
      
      // Check if word is outside viewport or near edges
      const isOutOfView = wordRect.top < containerRect.top + 100 || wordRect.bottom > containerRect.bottom - 100;
      
      if (isOutOfView) {
        // Smooth scroll with offset to keep word in comfortable reading position
        const offset = containerRect.height / 3; // Position word at 1/3 from top
        const targetScroll = wordElement.offsetTop - offset;
        
        containerElement.scrollTo({
          top: targetScroll,
          behavior: 'smooth'
        });
      }
    }
  }, [currentWordIndex, isReading]);

  // Initialize voices
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = synth.getVoices();
      setVoices(availableVoices);
      
      // Prioritize female voices
      const femaleVoice = availableVoices.find(v => 
        v.lang.startsWith('en-') && 
        (v.name.toLowerCase().includes('female') || 
         v.name.includes('Samantha') || 
         v.name.includes('Victoria') || 
         v.name.includes('Karen') || 
         v.name.includes('Susan') || 
         v.name.includes('Zira') ||
         v.name.includes('Google UK English Female') ||
         v.name.includes('Microsoft Zira') ||
         v.name.toLowerCase().includes('woman'))
      );
      
      if (femaleVoice) {
        setSelectedVoice(femaleVoice.name);
      } else {
        // Fallback to any good English voice
        const defaultVoice = availableVoices.find(v => v.lang.startsWith('en-'));
        if (defaultVoice) {
          setSelectedVoice(defaultVoice.name);
        } else if (availableVoices.length > 0) {
          setSelectedVoice(availableVoices[0].name);
        }
      }
    };

    loadVoices();
    if (speechSynthesis.onvoiceschanged !== undefined) {
      speechSynthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      synth.cancel();
    };
  }, []);

  // Load favorites from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('storyFavorites');
    if (saved) {
      setFavorites(JSON.parse(saved));
    }
  }, []);

  // Check if current story is favorited
  useEffect(() => {
    if (story) {
      setIsFavorite(favorites.some(f => f._id === story._id));
    }
  }, [story, favorites]);

  const fetchStory = async (withPrompt = false) => {
    setLoading(true);
    setError(null);
    stopReading();

    try {
      const res = await fetch(`https://shortstories-api.onrender.com/?t=${new Date().getTime()}`);
      if (!res.ok) {
        throw new Error('Failed to fetch story');
      }
      const data = await res.json();
      
      // If user provided input, append it as a note (since this API doesn't support custom prompts)
      if (withPrompt && (userPrompt || selectedGenre)) {
        data.customNote = `Generated with preferences: ${selectedGenre ? `Genre: ${selectedGenre}` : ''} ${userPrompt ? `Theme: ${userPrompt}` : ''}`;
      }
      
      setStory(data);
      setStoryHistory(prev => [data, ...prev.slice(0, 9)]); // Keep last 10 stories
      setShowPromptModal(false);
      setUserPrompt('');
      setSelectedGenre('');
    } catch (err) {
      console.error(err);
      setError("We couldn't conjure a story right now. The magic servers might be resting. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const toggleReading = () => {
    if (isReading) {
      stopReading();
    } else {
      startReading();
    }
  };

  const startReading = () => {
    if (!story) return;

    const textToRead = `${story.title}. By ${story.author}. ${story.story}. ${story.moral ? `The moral of the story is: ${story.moral}` : ''}`;
    
    synth.cancel();

    const utterance = new SpeechSynthesisUtterance(textToRead);
    
    if (selectedVoice) {
      const voice = voices.find(v => v.name === selectedVoice);
      if (voice) utterance.voice = voice;
    }
    
    utterance.rate = rate;
    utterance.pitch = pitch + 0.1; // Slightly higher pitch for female voice

    utterance.onstart = () => {
      setIsReading(true);
      setCurrentWordIndex(0);
    };
    
    utterance.onend = () => {
      setIsReading(false);
      setReadingProgress(0);
      setCurrentWordIndex(-1);
    };
    
    utterance.onerror = (e) => {
      console.error("Speech synthesis error", e);
      setIsReading(false);
      setReadingProgress(0);
      setCurrentWordIndex(-1);
    };

    // Word boundary tracking for highlighting
    utterance.onboundary = (event) => {
      if (event.charIndex !== undefined) {
        const progress = (event.charIndex / textToRead.length) * 100;
        setReadingProgress(progress);
        
        // Calculate which word is being spoken
        const textUpToNow = textToRead.substring(0, event.charIndex);
        const wordsSoFar = textUpToNow.split(/\s+/).length - 1;
        setCurrentWordIndex(wordsSoFar);
      }
    };

    synth.speak(utterance);
  };

  const stopReading = () => {
    synth.cancel();
    setIsReading(false);
    setReadingProgress(0);
    setCurrentWordIndex(-1);
  };

  const toggleFavorite = () => {
    if (!story) return;
    
    if (isFavorite) {
      const updated = favorites.filter(f => f._id !== story._id);
      setFavorites(updated);
      localStorage.setItem('storyFavorites', JSON.stringify(updated));
    } else {
      const updated = [...favorites, story];
      setFavorites(updated);
      localStorage.setItem('storyFavorites', JSON.stringify(updated));
    }
  };

  const loadStoryFromHistory = (selectedStory: Story) => {
    setStory(selectedStory);
    setShowHistory(false);
    stopReading();
  };

  // Initial fetch
  useEffect(() => {
    fetchStory();
  }, []);

  return (
    <div className="min-h-screen bg-[#000d1a] text-slate-200 selection:bg-indigo-500/30 font-sans relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {/* Base gradient layer */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#001529] via-[#000d1a] to-[#001a33]" />

        {/* Aurora Borealis effect */}
        <motion.div
          animate={{
            opacity: [0.3, 0.6, 0.3],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-0 left-0 w-full h-full"
          style={{
            background: 'radial-gradient(ellipse at 30% 20%, rgba(0, 71, 171, 0.4) 0%, transparent 50%), radial-gradient(ellipse at 70% 80%, rgba(30, 64, 175, 0.3) 0%, transparent 50%)',
          }}
        />

        {/* Flowing light streams */}
        <motion.div
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%'],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'linear-gradient(45deg, transparent 30%, rgba(59, 130, 246, 0.3) 50%, transparent 70%)',
            backgroundSize: '200% 200%',
          }}
        />

        {/* Large animated orbs with glow */}
        <motion.div 
          animate={{ 
            x: ['-20%', '120%'],
            y: ['0%', '60%', '0%'],
            scale: [1, 1.3, 1],
          }}
          transition={{ 
            duration: 35,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute w-[700px] h-[700px] rounded-full opacity-40"
          style={{
            background: 'radial-gradient(circle, rgba(0, 71, 171, 0.6) 0%, rgba(30, 64, 175, 0.3) 30%, transparent 70%)',
            filter: 'blur(80px)',
            boxShadow: '0 0 200px 50px rgba(0, 71, 171, 0.3)',
          }}
        />
        
        <motion.div 
          animate={{ 
            x: ['120%', '-20%'],
            y: ['100%', '30%', '100%'],
            scale: [1.2, 1, 1.2],
          }}
          transition={{ 
            duration: 40,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute w-[800px] h-[800px] rounded-full opacity-40"
          style={{
            background: 'radial-gradient(circle, rgba(30, 58, 138, 0.6) 0%, rgba(29, 78, 216, 0.3) 30%, transparent 70%)',
            filter: 'blur(90px)',
            boxShadow: '0 0 250px 60px rgba(30, 58, 138, 0.3)',
          }}
        />

        <motion.div 
          animate={{ 
            x: ['50%', '0%', '100%', '50%'],
            y: ['50%', '0%', '50%', '100%', '50%'],
            scale: [1, 1.4, 1, 1.2, 1],
          }}
          transition={{ 
            duration: 50,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute w-[600px] h-[600px] rounded-full opacity-30"
          style={{
            background: 'radial-gradient(circle, rgba(37, 99, 235, 0.5) 0%, rgba(29, 78, 216, 0.2) 40%, transparent 70%)',
            filter: 'blur(70px)',
            boxShadow: '0 0 180px 40px rgba(37, 99, 235, 0.2)',
          }}
        />

        {/* Animated wave layers */}
        <motion.div
          animate={{
            x: ['-100%', '0%'],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute bottom-0 left-0 w-[200%] h-[50%] opacity-15"
          style={{
            background: 'repeating-linear-gradient(45deg, transparent, transparent 80px, rgba(59, 130, 246, 0.4) 80px, rgba(59, 130, 246, 0.4) 82px)',
          }}
        />

        <motion.div
          animate={{
            x: ['0%', '-100%'],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute top-0 left-0 w-[200%] h-[50%] opacity-10"
          style={{
            background: 'repeating-linear-gradient(-45deg, transparent, transparent 100px, rgba(96, 165, 250, 0.3) 100px, rgba(96, 165, 250, 0.3) 102px)',
          }}
        />

        {/* Enhanced sparkles with various sizes */}
        {[...Array(80)].map((_, i) => {
          const size = Math.random() * 3 + 1;
          return (
            <motion.div
              key={i}
              animate={{
                opacity: [0, 1, 0.8, 0],
                scale: [0, 1.2, 1, 0],
                rotate: [0, 180, 360],
              }}
              transition={{
                duration: 2 + Math.random() * 5,
                repeat: Infinity,
                delay: Math.random() * 8,
                ease: "easeInOut"
              }}
              className="absolute rounded-full"
              style={{
                width: `${size}px`,
                height: `${size}px`,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                background: `radial-gradient(circle, rgba(125, 211, 252, ${0.8 + Math.random() * 0.2}) 0%, rgba(59, 130, 246, 0.4) 50%, transparent 100%)`,
                boxShadow: `0 0 ${size * 4}px ${size}px rgba(125, 211, 252, 0.3)`,
              }}
            />
          );
        })}

        {/* Constellation lines */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={`line-${i}`}
            animate={{
              opacity: [0.1, 0.4, 0.1],
              scaleX: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 8 + Math.random() * 6,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "easeInOut"
            }}
            className="absolute h-px bg-gradient-to-r from-transparent via-blue-400/30 to-transparent"
            style={{
              width: `${100 + Math.random() * 200}px`,
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              transform: `rotate(${Math.random() * 360}deg)`,
            }}
          />
        ))}

        {/* Animated hexagon pattern */}
        <motion.div
          animate={{
            opacity: [0.03, 0.08, 0.03],
            rotate: [0, 360],
          }}
          transition={{
            duration: 80,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(30deg, transparent 48%, rgba(59, 130, 246, 0.15) 49%, rgba(59, 130, 246, 0.15) 51%, transparent 52%),
              linear-gradient(150deg, transparent 48%, rgba(59, 130, 246, 0.15) 49%, rgba(59, 130, 246, 0.15) 51%, transparent 52%),
              linear-gradient(270deg, transparent 48%, rgba(59, 130, 246, 0.15) 49%, rgba(59, 130, 246, 0.15) 51%, transparent 52%)
            `,
            backgroundSize: '60px 104px',
          }}
        />

        {/* Central radial glow */}
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px]"
          style={{
            background: 'radial-gradient(circle, rgba(30, 58, 138, 0.4) 0%, rgba(30, 64, 175, 0.2) 30%, transparent 60%)',
            filter: 'blur(80px)',
          }}
        />

        {/* Shooting stars */}
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={`star-${i}`}
            animate={{
              x: [-100, window.innerWidth + 100],
              y: [-100, window.innerHeight / 2],
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 10 + Math.random() * 10,
              ease: "easeOut"
            }}
            className="absolute w-1 h-1 bg-cyan-300 rounded-full"
            style={{
              boxShadow: '0 0 20px 4px rgba(34, 211, 238, 0.8), -50px 0 30px 10px rgba(34, 211, 238, 0.3)',
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-12 md:py-20 flex flex-col min-h-screen">
        
        {/* Header */}
        <header className="flex flex-col items-center mb-12 text-center">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.1, rotate: 5 }}
            className="inline-flex items-center justify-center p-3 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-2xl mb-4 border border-indigo-500/30 shadow-lg shadow-indigo-500/20"
          >
            <Sparkles className="w-8 h-8 text-indigo-400" />
          </motion.div>
          <motion.h1 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-4xl md:text-6xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-blue-400 to-cyan-400 mb-4"
          >
            AI Story Weaver
          </motion.h1>
          <motion.p 
            initial={{ y: -10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-slate-400 max-w-lg text-lg"
          >
            Discover magical tales woven by AI. Customize your story preferences and let the magic read to you.
          </motion.p>
        </header>

        {/* Controls */}
        <div className="flex flex-wrap gap-4 justify-center items-center mb-12">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowPromptModal(true)}
            disabled={loading || isReading}
            className="group relative flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-full font-bold text-lg hover:from-indigo-500 hover:to-blue-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_40px_-10px_rgba(99,102,241,0.6)]"
          >
            <Wand2 className="w-5 h-5" />
            <span>Create Custom Story</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => fetchStory(false)}
            disabled={loading || isReading}
            className="group relative flex items-center gap-2 px-8 py-4 bg-white text-slate-900 rounded-full font-bold text-lg hover:bg-slate-100 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)]"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Sparkles className="w-5 h-5 group-hover:text-indigo-600 transition-colors" />
            )}
            <span>{loading ? 'Conjuring...' : 'Random Story'}</span>
          </motion.button>

          {story && !loading && (
            <>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={toggleReading}
                className={`flex items-center gap-2 px-8 py-4 rounded-full font-bold text-lg transition-all border-2 ${
                  isReading 
                    ? 'bg-rose-500/10 border-rose-500/50 text-rose-400 hover:bg-rose-500/20' 
                    : 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/20'
                }`}
              >
                {isReading ? (
                  <>
                    <Square className="w-5 h-5 fill-current" />
                    <span>Stop Reading</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>Read Story</span>
                  </>
                )}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={toggleFavorite}
                className={`flex items-center gap-2 p-4 rounded-full font-bold transition-all border-2 ${
                  isFavorite 
                    ? 'bg-pink-500/20 border-pink-500/50 text-pink-400' 
                    : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:border-pink-500/50 hover:text-pink-400'
                }`}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
              </motion.button>
            </>
          )}

          {storyHistory.length > 0 && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 p-4 rounded-full font-bold transition-all border-2 bg-slate-800/50 border-slate-700/50 text-slate-400 hover:border-blue-500/50 hover:text-blue-400"
            >
              <Clock className="w-5 h-5" />
            </motion.button>
          )}
        </div>

        {/* Reading Progress Bar */}
        {isReading && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 bg-slate-800/50 rounded-full h-3 overflow-hidden border border-slate-700/50"
          >
            <motion.div 
              className="h-full bg-gradient-to-r from-emerald-500 to-blue-500"
              style={{ width: `${readingProgress}%` }}
              transition={{ duration: 0.3 }}
            />
          </motion.div>
        )}

        {/* Story History Dropdown */}
        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, y: -20, height: 0 }}
              animate={{ opacity: 1, y: 0, height: 'auto' }}
              exit={{ opacity: 0, y: -20, height: 0 }}
              className="mb-8 bg-slate-800/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 overflow-hidden"
            >
              <h3 className="text-lg font-bold text-indigo-400 mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Recent Stories
              </h3>
              <div className="grid gap-3 max-h-80 overflow-y-auto">
                {storyHistory.map((historyStory, idx) => (
                  <motion.button
                    key={historyStory._id + idx}
                    whileHover={{ scale: 1.02, x: 5 }}
                    onClick={() => loadStoryFromHistory(historyStory)}
                    className="text-left p-4 bg-slate-900/50 hover:bg-slate-900/80 rounded-xl border border-slate-700/30 hover:border-indigo-500/50 transition-all"
                  >
                    <div className="font-semibold text-white mb-1">{historyStory.title}</div>
                    <div className="text-sm text-slate-400">by {historyStory.author}</div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Story Display Area */}
        <main className="flex-grow flex flex-col items-center w-full relative">
          
          <AnimatePresence mode="wait">
            {error && (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="w-full max-w-2xl p-6 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-400 text-center"
              >
                {error}
              </motion.div>
            )}

            {loading && !story && (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-20"
              >
                <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mb-4" />
                <p className="text-slate-400 animate-pulse">Consulting the ancient scrolls...</p>
              </motion.div>
            )}

            {story && !error && (
              <motion.div
                key={story._id || 'story'}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-3xl shadow-2xl overflow-hidden"
              >
                {/* Story Hero Image */}
                <div className="w-full h-64 md:h-80 relative overflow-hidden bg-slate-900">
                  <motion.img 
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.8 }}
                    src={`https://picsum.photos/seed/${story._id || story.title.replace(/\s+/g, '')}/1200/600`} 
                    alt="Story Cover" 
                    className="w-full h-full object-cover opacity-70 mix-blend-overlay"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
                  
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="absolute bottom-0 left-0 w-full p-6 md:p-12 pb-8"
                  >
                    <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 leading-tight drop-shadow-lg">
                      {story.title}
                    </h2>
                    <div className="flex items-center gap-2 text-indigo-300 font-medium">
                      <User className="w-4 h-4" />
                      <span>{story.author || 'Unknown Author'}</span>
                    </div>
                  </motion.div>
                </div>

                <div className="p-6 md:p-12 pt-8" ref={storyContentRef}>

                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="mb-12 font-serif text-lg leading-relaxed max-h-[600px] overflow-y-auto pr-4 scroll-smooth"
                  style={{
                    scrollbarWidth: 'thin',
                    scrollbarColor: 'rgba(99, 102, 241, 0.5) rgba(30, 41, 59, 0.3)',
                  }}
                >
                  {story.story.split('\n').map((paragraph, pIndex) => {
                    if (!paragraph.trim()) return null;
                    
                    const paragraphWords = paragraph.trim().split(/\s+/);
                    
                    // Calculate the starting word index for this paragraph
                    const previousText = story.story.split('\n').slice(0, pIndex).join(' ');
                    const titleAndAuthor = `${story.title}. By ${story.author}.`;
                    const wordsBeforeParagraph = (titleAndAuthor + ' ' + previousText).split(/\s+/).length;
                    
                    return (
                      <motion.p 
                        key={pIndex} 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 + pIndex * 0.1 }}
                        className="mb-6 first-letter:text-5xl first-letter:font-bold first-letter:text-indigo-400 first-letter:mr-1 first-letter:float-left"
                      >
                        {paragraphWords.map((word, wIndex) => {
                          const absoluteWordIndex = wordsBeforeParagraph + wIndex;
                          const isCurrentWord = isReading && currentWordIndex === absoluteWordIndex;
                          
                          return (
                            <span
                              key={wIndex}
                              ref={isCurrentWord ? currentWordRef : null}
                              className={`transition-all duration-300 inline-block ${
                                isCurrentWord 
                                  ? 'text-cyan-300 font-bold bg-cyan-500/20 px-1 rounded shadow-lg shadow-cyan-500/50 scale-110' 
                                  : 'text-slate-300'
                              }`}
                            >
                              {word}{' '}
                            </span>
                          );
                        })}
                      </motion.p>
                    );
                  })}
                </motion.div>

                {story.moral && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                    className="mt-12 p-6 bg-gradient-to-br from-indigo-950/40 to-purple-950/40 border border-indigo-500/30 rounded-2xl relative overflow-hidden shadow-lg"
                  >
                    <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-indigo-500 to-purple-500" />
                    <div className="flex items-start gap-4">
                      <BookMarked className="w-6 h-6 text-indigo-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="font-semibold text-indigo-300 mb-2 uppercase tracking-wider text-sm">The Moral</h3>
                        <p className="text-slate-200 font-medium text-lg leading-relaxed italic">
                          "{story.moral}"
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
        
        {/* TTS Settings */}
        {voices.length > 0 && (
           <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             transition={{ delay: 0.8 }}
             className="mt-16 pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6 opacity-60 hover:opacity-100 transition-opacity"
           >
             <div className="flex items-center gap-2 text-slate-400 mb-2 md:mb-0">
               <Settings className="w-4 h-4" />
               <span className="text-sm font-medium">Voice Settings</span>
             </div>
             
             <div className="flex flex-wrap items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-slate-500" />
                  <select 
                    value={selectedVoice}
                    onChange={(e) => setSelectedVoice(e.target.value)}
                    className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-slate-300 focus:outline-none focus:border-indigo-500 max-w-[200px]"
                  >
                    {voices.map((voice) => (
                      <option key={voice.name} value={voice.name}>
                        {voice.name} ({voice.lang})
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Speed</span>
                  <input 
                    type="range" 
                    min="0.5" max="2" step="0.1" 
                    value={rate} 
                    onChange={(e) => setRate(parseFloat(e.target.value))}
                    className="w-24 accent-indigo-500"
                  />
                  <span className="text-slate-400 w-8">{rate}x</span>
                </div>
             </div>
           </motion.div>
        )}
      </div>

      {/* Custom Prompt Modal */}
      <AnimatePresence>
        {showPromptModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowPromptModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-900 border-2 border-indigo-500/30 rounded-3xl p-8 max-w-lg w-full shadow-2xl relative"
            >
              <button
                onClick={() => setShowPromptModal(false)}
                className="absolute top-4 right-4 p-2 hover:bg-slate-800 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-indigo-500/20 rounded-xl">
                  <Wand2 className="w-6 h-6 text-indigo-400" />
                </div>
                <h2 className="text-2xl font-bold text-white">Customize Your Story</h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Select a Genre (Optional)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {genres.map((genre) => (
                      <motion.button
                        key={genre}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setSelectedGenre(genre === selectedGenre ? '' : genre)}
                        className={`p-3 rounded-xl font-medium transition-all ${
                          selectedGenre === genre
                            ? 'bg-indigo-600 text-white border-2 border-indigo-400'
                            : 'bg-slate-800 text-slate-300 border-2 border-slate-700 hover:border-indigo-500/50'
                        }`}
                      >
                        {genre}
                      </motion.button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Add Your Theme or Ideas (Optional)
                  </label>
                  <textarea
                    value={userPrompt}
                    onChange={(e) => setUserPrompt(e.target.value)}
                    placeholder="e.g., A brave knight, magical forest, friendship..."
                    className="w-full bg-slate-800 border-2 border-slate-700 rounded-xl px-4 py-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none"
                    rows={4}
                  />
                </div>

                <div className="flex gap-3">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => fetchStory(true)}
                    disabled={loading}
                    className="flex-1 py-4 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-full font-bold hover:from-indigo-500 hover:to-blue-500 transition-all disabled:opacity-50"
                  >
                    {loading ? (
                      <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                    ) : (
                      'Generate Story'
                    )}
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setShowPromptModal(false)}
                    className="px-6 py-4 bg-slate-800 text-slate-300 rounded-full font-bold hover:bg-slate-700 transition-all"
                  >
                    Cancel
                  </motion.button>
                </div>

                <p className="text-xs text-slate-500 text-center">
                  Note: The API provides random stories. Your preferences help us show what you'd like, but the actual story is randomly selected from our collection.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
